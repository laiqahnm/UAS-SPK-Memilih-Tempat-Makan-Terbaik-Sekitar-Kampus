<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container-fluid">

        <button type="button" id="sidebarCollapse" class="btn btn-outline-primary">
            <i class="fa fa-bars"></i>
            <span class="sr-only">Toggle Menu</span>
        </button>

        <h6 class="nav"> SPK PEMILIHAN TEMPAT MAKAN TERBAIK DISEKITAR KAMPUS |<b>| METODE SAW</b></h6>
    </div>
</nav>
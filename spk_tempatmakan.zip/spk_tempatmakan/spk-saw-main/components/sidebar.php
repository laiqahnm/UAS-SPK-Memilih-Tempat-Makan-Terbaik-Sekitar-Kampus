<nav id="sidebar" class="active">
    <h1><a href="index.php" class="logo">AC</a></h1>
    <ul class="list-unstyled components mb-5">
        <li>
            <a href="home.php"><span class="fa fa-home"></span> Beranda</a>
        </li>
        <li>
            <a href="index.php"><span class="fa fa-user"></span> Alternatif</a>
        </li>
        <li class="active">
            <a href="kriteria.php"><span class="fa fa-sticky-note"></span> Kriteria</a>
        </li>
        <li>
            <a href="penilaian.php"><span class="fa fa-list-ol"></span> Penilaian</a>
        </li>
        <li>
            <a href="hitung.php"><span class="fa fa-cogs"></span> Hitung</a>
        </li>
    </ul>
</nav>